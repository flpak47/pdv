<?php

    define("DB_USER", "root");
    define("DB_SENHA", "elaborata");
    define("DB_HOST", "localhost");
    define("DB_BASE", "pdv");

?>